exports.myDateTime = function () {
    return "Entre na pagina do medico";
};
