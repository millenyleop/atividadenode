var http = require('http');
var dt = require('./pginicial.js');

http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/html'});
  res.write("Medical Group " + dt.myDateTime());
  res.end();
}).listen(5007);

