exports.myDateTime = function () {
    return "Agende sua Consulta: " +  Date();
  };
