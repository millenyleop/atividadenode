exports.myDateTime = function () {
var cadastro= "ola isso e um teste";
    return cadastro;
  };
